from distutils.core import setup

setup(
    name='sdk',
    version='1.0.1',
    description='sdk for di input , output and param',
    url='',
    license='No License',
    platforms='python 3x',
    py_modules=['dtk_open_platform'],
    package_dir={'': 'lib'},
    #packages=['lib', 'common.http']
)